# Data Release: Measurement of Neutron Production in Atmospheric Neutrino Interactions at Super-Kamiokande

This data release accompanies the article ["Measurement of neutron production in atmospheric neutrino interactions at Super-Kamiokande"](https://arxiv.org/abs/2505.04409). The data provided here includes observed average neutron multiplicity in atmospheric neutrino interactions at Super-Kamiokande (SK) as a function of the event's visible energy, along with model predictions using various combinations of final-state interaction (FSI) models and secondary hadron interaction models. 

For details on the data selection and compared models, please refer to the associated article on [arXiv](https://arxiv.org/abs/2505.04409).

---

## Files Included:

### 1. `x_bin_edges.txt`:
Contains the x bin edges for all data, formatted as a list, which is equivalent to `np.logspace(np.log10(30), 4, 51)` in `numpy`. The bin edges are common for all event types included in the two comma-delimited csv files below.

### 2. `data_observations.csv`:
Contains the observed SK data.
  - `event_type`: (`all`, `sr`, `mr`)
    - `all`: All events that pass the selection criteria.
    - `sr`: Single-ring events only.
    - `mr`: Multi-ring events only.
  - `x_bin_id`: Bin ID to match between data observations and model predictions.
  - `x_bin_center`: Mean value of visible energy for events in the x bin.
  - `y_nmult_est`: Average estimated neutron multiplicity for events in the x bin.

Data includes estimated y errors:
  - `yerr_total`: Total uncertainty for the observed `y_nmult_est`, calculated as the L2 norm of the following uncertainty components.
  - `yerr_stat`: Statistical uncertainty.
  - `yerr_effscale`: Systematic uncertainty due to uncertainty in neutron signal efficiency scale (assumed to be fully correlated across all bins)
  - `yerr_other`: Other systematic uncertainties (assumed to be independent and uncorrelated across bins)

### 3. `model_predictions.csv`:
Contains various model predictions for comparison with the observed data. 
  - `fsi_model`: FSI model used within neutrino event generators:

    (`"neut_5.4.0"`, `"neut_5.6.3"`, `"genie_ha"`, `"genie_hn"`, `"genie_bert"`, `"genie_incl"`)
  - `sec_model`: Secondary hadron-nucleus interaction model used within detector simulators:

    (`"sk45_default"`, `"sk6_default"`, `"g3_gcalor"`, `"g4_bert"`, `"g4_bert_pc"`, `"g4_incl_pc"`)

---
